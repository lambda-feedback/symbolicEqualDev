from .evaluation import evaluation_function

def run():
    number_of_samples = 1000
    n = 0
    while n < number_of_samples:
        n += 1
        params = {
            "strict_syntax": False,
         #   "rtol": 0.05,
        }
        response = "a+c"
        answer = "a+b"
        result = evaluation_function(response, answer, params)

if __name__ == "__main__":
    run()